var users = [
  { name: "Michael", age: 37 },
  { name: "John", age: 30 },
  { name: "David", age: 27 },
];

// iterate array 'users'
for (var i = 0; i < users.length; i++) {
  console.log(users[i].name + " - " + users[i].age); // display object properties as requested
}
